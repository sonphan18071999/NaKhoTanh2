﻿namespace QuanLiXe
{
    partial class ChiaCaUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvNV = new System.Windows.Forms.DataGridView();
            this.txtmaNV = new System.Windows.Forms.TextBox();
            this.pnPicture = new System.Windows.Forms.Panel();
            this.ptbCasang = new System.Windows.Forms.PictureBox();
            this.ptbToi = new System.Windows.Forms.PictureBox();
            this.ptbCachieu = new System.Windows.Forms.PictureBox();
            this.pnAll = new System.Windows.Forms.Panel();
            this.comboKhu = new System.Windows.Forms.ComboBox();
            this.btnAddCa = new System.Windows.Forms.Button();
            this.pnCa = new System.Windows.Forms.Panel();
            this.radioToi = new System.Windows.Forms.RadioButton();
            this.radioChieu = new System.Windows.Forms.RadioButton();
            this.radioSang = new System.Windows.Forms.RadioButton();
            this.pnTinhtrang = new System.Windows.Forms.Panel();
            this.radioBusy = new System.Windows.Forms.RadioButton();
            this.radioFree = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnList = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).BeginInit();
            this.pnPicture.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptbCasang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbToi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbCachieu)).BeginInit();
            this.pnAll.SuspendLayout();
            this.pnCa.SuspendLayout();
            this.pnTinhtrang.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvNV
            // 
            this.dgvNV.AllowUserToAddRows = false;
            this.dgvNV.AllowUserToDeleteRows = false;
            this.dgvNV.AllowUserToResizeColumns = false;
            this.dgvNV.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvNV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvNV.BackgroundColor = System.Drawing.Color.LightSkyBlue;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvNV.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvNV.Location = new System.Drawing.Point(95, 548);
            this.dgvNV.Name = "dgvNV";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvNV.RowHeadersVisible = false;
            this.dgvNV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvNV.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvNV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvNV.Size = new System.Drawing.Size(1062, 359);
            this.dgvNV.TabIndex = 67;
            this.dgvNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNV_CellClick);
            // 
            // txtmaNV
            // 
            this.txtmaNV.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtmaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaNV.Location = new System.Drawing.Point(249, 9);
            this.txtmaNV.Name = "txtmaNV";
            this.txtmaNV.Size = new System.Drawing.Size(167, 31);
            this.txtmaNV.TabIndex = 4;
            // 
            // pnPicture
            // 
            this.pnPicture.Controls.Add(this.ptbCasang);
            this.pnPicture.Controls.Add(this.ptbToi);
            this.pnPicture.Controls.Add(this.ptbCachieu);
            this.pnPicture.Location = new System.Drawing.Point(58, 84);
            this.pnPicture.Name = "pnPicture";
            this.pnPicture.Size = new System.Drawing.Size(1092, 345);
            this.pnPicture.TabIndex = 66;
            // 
            // ptbCasang
            // 
            this.ptbCasang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ptbCasang.Location = new System.Drawing.Point(67, 32);
            this.ptbCasang.Name = "ptbCasang";
            this.ptbCasang.Size = new System.Drawing.Size(260, 286);
            this.ptbCasang.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbCasang.TabIndex = 0;
            this.ptbCasang.TabStop = false;
            this.ptbCasang.Click += new System.EventHandler(this.ptbCasang_Click);
            // 
            // ptbToi
            // 
            this.ptbToi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ptbToi.Location = new System.Drawing.Point(623, 23);
            this.ptbToi.Name = "ptbToi";
            this.ptbToi.Size = new System.Drawing.Size(270, 286);
            this.ptbToi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbToi.TabIndex = 0;
            this.ptbToi.TabStop = false;
            this.ptbToi.Click += new System.EventHandler(this.ptbToi_Click);
            // 
            // ptbCachieu
            // 
            this.ptbCachieu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ptbCachieu.Location = new System.Drawing.Point(333, 23);
            this.ptbCachieu.Name = "ptbCachieu";
            this.ptbCachieu.Size = new System.Drawing.Size(284, 286);
            this.ptbCachieu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbCachieu.TabIndex = 0;
            this.ptbCachieu.TabStop = false;
            this.ptbCachieu.Click += new System.EventHandler(this.ptbCachieu_Click);
            // 
            // pnAll
            // 
            this.pnAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnAll.Controls.Add(this.comboKhu);
            this.pnAll.Controls.Add(this.btnAddCa);
            this.pnAll.Controls.Add(this.pnCa);
            this.pnAll.Controls.Add(this.txtmaNV);
            this.pnAll.Controls.Add(this.pnTinhtrang);
            this.pnAll.Controls.Add(this.label4);
            this.pnAll.Controls.Add(this.label6);
            this.pnAll.Controls.Add(this.label7);
            this.pnAll.Controls.Add(this.label5);
            this.pnAll.Location = new System.Drawing.Point(115, 139);
            this.pnAll.Name = "pnAll";
            this.pnAll.Size = new System.Drawing.Size(1035, 403);
            this.pnAll.TabIndex = 11;
            // 
            // comboKhu
            // 
            this.comboKhu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboKhu.FormattingEnabled = true;
            this.comboKhu.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
            "G",
            "H",
            "J"});
            this.comboKhu.Location = new System.Drawing.Point(249, 76);
            this.comboKhu.Name = "comboKhu";
            this.comboKhu.Size = new System.Drawing.Size(167, 33);
            this.comboKhu.TabIndex = 11;
            // 
            // btnAddCa
            // 
            this.btnAddCa.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddCa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCa.Location = new System.Drawing.Point(565, 24);
            this.btnAddCa.Name = "btnAddCa";
            this.btnAddCa.Size = new System.Drawing.Size(201, 61);
            this.btnAddCa.TabIndex = 6;
            this.btnAddCa.Text = "Thêm ca";
            this.btnAddCa.UseVisualStyleBackColor = true;
            this.btnAddCa.Click += new System.EventHandler(this.btnAddCa_Click);
            // 
            // pnCa
            // 
            this.pnCa.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnCa.Controls.Add(this.radioToi);
            this.pnCa.Controls.Add(this.radioChieu);
            this.pnCa.Controls.Add(this.radioSang);
            this.pnCa.Location = new System.Drawing.Point(249, 173);
            this.pnCa.Name = "pnCa";
            this.pnCa.Size = new System.Drawing.Size(167, 117);
            this.pnCa.TabIndex = 10;
            // 
            // radioToi
            // 
            this.radioToi.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioToi.AutoSize = true;
            this.radioToi.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioToi.Location = new System.Drawing.Point(22, 85);
            this.radioToi.Name = "radioToi";
            this.radioToi.Size = new System.Drawing.Size(60, 29);
            this.radioToi.TabIndex = 1;
            this.radioToi.TabStop = true;
            this.radioToi.Text = "Tối";
            this.radioToi.UseVisualStyleBackColor = true;
            // 
            // radioChieu
            // 
            this.radioChieu.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioChieu.AutoSize = true;
            this.radioChieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioChieu.Location = new System.Drawing.Point(22, 50);
            this.radioChieu.Name = "radioChieu";
            this.radioChieu.Size = new System.Drawing.Size(86, 29);
            this.radioChieu.TabIndex = 0;
            this.radioChieu.TabStop = true;
            this.radioChieu.Text = "Chiều";
            this.radioChieu.UseVisualStyleBackColor = true;
            // 
            // radioSang
            // 
            this.radioSang.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioSang.AutoSize = true;
            this.radioSang.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioSang.Location = new System.Drawing.Point(22, 12);
            this.radioSang.Name = "radioSang";
            this.radioSang.Size = new System.Drawing.Size(80, 29);
            this.radioSang.TabIndex = 0;
            this.radioSang.TabStop = true;
            this.radioSang.Text = "Sáng";
            this.radioSang.UseVisualStyleBackColor = true;
            // 
            // pnTinhtrang
            // 
            this.pnTinhtrang.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnTinhtrang.Controls.Add(this.radioBusy);
            this.pnTinhtrang.Controls.Add(this.radioFree);
            this.pnTinhtrang.Location = new System.Drawing.Point(220, 319);
            this.pnTinhtrang.Name = "pnTinhtrang";
            this.pnTinhtrang.Size = new System.Drawing.Size(213, 60);
            this.pnTinhtrang.TabIndex = 9;
            // 
            // radioBusy
            // 
            this.radioBusy.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioBusy.AutoSize = true;
            this.radioBusy.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioBusy.Location = new System.Drawing.Point(96, 19);
            this.radioBusy.Name = "radioBusy";
            this.radioBusy.Size = new System.Drawing.Size(78, 29);
            this.radioBusy.TabIndex = 8;
            this.radioBusy.TabStop = true;
            this.radioBusy.Text = "Busy";
            this.radioBusy.UseVisualStyleBackColor = true;
            // 
            // radioFree
            // 
            this.radioFree.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.radioFree.AutoSize = true;
            this.radioFree.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioFree.Location = new System.Drawing.Point(16, 19);
            this.radioFree.Name = "radioFree";
            this.radioFree.Size = new System.Drawing.Size(74, 29);
            this.radioFree.TabIndex = 7;
            this.radioFree.TabStop = true;
            this.radioFree.Text = "Free";
            this.radioFree.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 37);
            this.label4.TabIndex = 5;
            this.label4.Text = "Mã nhân viên";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(29, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 37);
            this.label6.TabIndex = 5;
            this.label6.Text = "Khu";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(29, 299);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(163, 37);
            this.label7.TabIndex = 5;
            this.label7.Text = "Tình trạng";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 37);
            this.label5.TabIndex = 5;
            this.label5.Text = "Ca";
            // 
            // btnList
            // 
            this.btnList.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnList.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnList.Location = new System.Drawing.Point(357, 13);
            this.btnList.Name = "btnList";
            this.btnList.Size = new System.Drawing.Size(213, 66);
            this.btnList.TabIndex = 65;
            this.btnList.Text = "Danh sách nhân viên";
            this.btnList.UseVisualStyleBackColor = true;
            this.btnList.Click += new System.EventHandler(this.btnList_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(104, 30);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(195, 37);
            this.btnBack.TabIndex = 64;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // ChiaCaUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dgvNV);
            this.Controls.Add(this.pnPicture);
            this.Controls.Add(this.btnList);
            this.Controls.Add(this.pnAll);
            this.Controls.Add(this.btnBack);
            this.Name = "ChiaCaUC";
            this.Size = new System.Drawing.Size(1185, 810);
            this.Load += new System.EventHandler(this.ChiaCaUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).EndInit();
            this.pnPicture.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptbCasang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbToi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbCachieu)).EndInit();
            this.pnAll.ResumeLayout(false);
            this.pnAll.PerformLayout();
            this.pnCa.ResumeLayout(false);
            this.pnCa.PerformLayout();
            this.pnTinhtrang.ResumeLayout(false);
            this.pnTinhtrang.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dgvNV;
        private System.Windows.Forms.TextBox txtmaNV;
        private System.Windows.Forms.Panel pnPicture;
        private System.Windows.Forms.Panel pnAll;
        private System.Windows.Forms.ComboBox comboKhu;
        private System.Windows.Forms.Button btnAddCa;
        private System.Windows.Forms.Panel pnCa;
        private System.Windows.Forms.RadioButton radioToi;
        private System.Windows.Forms.RadioButton radioChieu;
        private System.Windows.Forms.RadioButton radioSang;
        private System.Windows.Forms.Panel pnTinhtrang;
        private System.Windows.Forms.RadioButton radioBusy;
        private System.Windows.Forms.RadioButton radioFree;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox ptbCasang;
        private System.Windows.Forms.PictureBox ptbToi;
        private System.Windows.Forms.PictureBox ptbCachieu;
        private System.Windows.Forms.Button btnList;
        private System.Windows.Forms.Button btnBack;
    }
}
