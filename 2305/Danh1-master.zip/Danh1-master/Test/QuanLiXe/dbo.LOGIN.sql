﻿CREATE TABLE [dbo].[Login] (
    [ID]       INT          NOT NULL,
    [Username] VARCHAR (10) NULL,
    [Password] VARCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);
