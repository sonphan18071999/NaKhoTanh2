﻿namespace QuanLiXe
{
    partial class KhachHangChinhUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KhachHangChinhUC));
            this.panelKhachHang = new System.Windows.Forms.Panel();
            this.menuStripLogout = new System.Windows.Forms.MenuStrip();
            this.menuName = new System.Windows.Forms.ToolStripMenuItem();
            this.menuLogout = new System.Windows.Forms.ToolStripMenuItem();
            this.btnKHoaDon = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnKThueXe = new System.Windows.Forms.Button();
            this.btnKDichVuThue = new System.Windows.Forms.Button();
            this.btnKThongTin = new System.Windows.Forms.Button();
            this.panelClickKH = new System.Windows.Forms.Panel();
            this.btGioiThieuKH = new System.Windows.Forms.Button();
            this.kThongTinKH2 = new QuanLiXe.KThongTinKH();
            this.gioiThieuUC1 = new QuanLiXe.UserControls.GioiThieuUC();
            this.panelKhachHang.SuspendLayout();
            this.menuStripLogout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelKhachHang
            // 
            this.panelKhachHang.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panelKhachHang.Controls.Add(this.menuStripLogout);
            this.panelKhachHang.Controls.Add(this.btnKHoaDon);
            this.panelKhachHang.Controls.Add(this.pictureBox2);
            this.panelKhachHang.Controls.Add(this.btnKThueXe);
            this.panelKhachHang.Controls.Add(this.btnKDichVuThue);
            this.panelKhachHang.Controls.Add(this.btnKThongTin);
            this.panelKhachHang.Controls.Add(this.panelClickKH);
            this.panelKhachHang.Controls.Add(this.btGioiThieuKH);
            this.panelKhachHang.Location = new System.Drawing.Point(0, 0);
            this.panelKhachHang.Name = "panelKhachHang";
            this.panelKhachHang.Size = new System.Drawing.Size(357, 854);
            this.panelKhachHang.TabIndex = 11;
            // 
            // menuStripLogout
            // 
            this.menuStripLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.menuStripLogout.BackColor = System.Drawing.Color.RoyalBlue;
            this.menuStripLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.menuStripLogout.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStripLogout.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStripLogout.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripLogout.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuName});
            this.menuStripLogout.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStripLogout.Location = new System.Drawing.Point(6, 815);
            this.menuStripLogout.Name = "menuStripLogout";
            this.menuStripLogout.Size = new System.Drawing.Size(97, 39);
            this.menuStripLogout.TabIndex = 67;
            this.menuStripLogout.Text = "menuStrip1";
            // 
            // menuName
            // 
            this.menuName.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuLogout});
            this.menuName.Name = "menuName";
            this.menuName.Size = new System.Drawing.Size(89, 35);
            this.menuName.Text = "Name";
            this.menuName.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            // 
            // menuLogout
            // 
            this.menuLogout.Name = "menuLogout";
            this.menuLogout.Size = new System.Drawing.Size(200, 36);
            this.menuLogout.Text = "Đăng xuất";
            // 
            // btnKHoaDon
            // 
            this.btnKHoaDon.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnKHoaDon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKHoaDon.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnKHoaDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKHoaDon.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKHoaDon.ForeColor = System.Drawing.Color.Transparent;
            this.btnKHoaDon.Location = new System.Drawing.Point(6, 641);
            this.btnKHoaDon.Name = "btnKHoaDon";
            this.btnKHoaDon.Size = new System.Drawing.Size(346, 108);
            this.btnKHoaDon.TabIndex = 8;
            this.btnKHoaDon.Text = "Hóa Đơn";
            this.btnKHoaDon.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(32, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(282, 147);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // btnKThueXe
            // 
            this.btnKThueXe.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnKThueXe.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKThueXe.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnKThueXe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKThueXe.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKThueXe.ForeColor = System.Drawing.Color.Transparent;
            this.btnKThueXe.Location = new System.Drawing.Point(6, 520);
            this.btnKThueXe.Name = "btnKThueXe";
            this.btnKThueXe.Size = new System.Drawing.Size(346, 116);
            this.btnKThueXe.TabIndex = 5;
            this.btnKThueXe.Text = "Dịch Vụ Thuê Xe";
            this.btnKThueXe.UseVisualStyleBackColor = true;
            // 
            // btnKDichVuThue
            // 
            this.btnKDichVuThue.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnKDichVuThue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKDichVuThue.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnKDichVuThue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKDichVuThue.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKDichVuThue.ForeColor = System.Drawing.Color.Transparent;
            this.btnKDichVuThue.Location = new System.Drawing.Point(6, 414);
            this.btnKDichVuThue.Name = "btnKDichVuThue";
            this.btnKDichVuThue.Size = new System.Drawing.Size(346, 100);
            this.btnKDichVuThue.TabIndex = 4;
            this.btnKDichVuThue.Text = "Dịch Vụ Đăng Ký";
            this.btnKDichVuThue.UseVisualStyleBackColor = true;
            // 
            // btnKThongTin
            // 
            this.btnKThongTin.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnKThongTin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKThongTin.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btnKThongTin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKThongTin.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKThongTin.ForeColor = System.Drawing.Color.Transparent;
            this.btnKThongTin.Location = new System.Drawing.Point(6, 298);
            this.btnKThongTin.Name = "btnKThongTin";
            this.btnKThongTin.Size = new System.Drawing.Size(346, 110);
            this.btnKThongTin.TabIndex = 2;
            this.btnKThongTin.Text = "Thông tin khách hàng";
            this.btnKThongTin.UseVisualStyleBackColor = true;
            this.btnKThongTin.Click += new System.EventHandler(this.btnKThongTin_Click);
            // 
            // panelClickKH
            // 
            this.panelClickKH.BackColor = System.Drawing.Color.AliceBlue;
            this.panelClickKH.Location = new System.Drawing.Point(3, 176);
            this.panelClickKH.Name = "panelClickKH";
            this.panelClickKH.Size = new System.Drawing.Size(23, 80);
            this.panelClickKH.TabIndex = 1;
            // 
            // btGioiThieuKH
            // 
            this.btGioiThieuKH.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btGioiThieuKH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btGioiThieuKH.FlatAppearance.BorderColor = System.Drawing.Color.CornflowerBlue;
            this.btGioiThieuKH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGioiThieuKH.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGioiThieuKH.ForeColor = System.Drawing.Color.Transparent;
            this.btGioiThieuKH.Location = new System.Drawing.Point(3, 176);
            this.btGioiThieuKH.Name = "btGioiThieuKH";
            this.btGioiThieuKH.Size = new System.Drawing.Size(349, 116);
            this.btGioiThieuKH.TabIndex = 0;
            this.btGioiThieuKH.Text = "Giới thiệu";
            this.btGioiThieuKH.UseVisualStyleBackColor = true;
            this.btGioiThieuKH.Click += new System.EventHandler(this.btGioiThieuKH_Click);
            // 
            // kThongTinKH2
            // 
            this.kThongTinKH2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.kThongTinKH2.Location = new System.Drawing.Point(358, 3);
            this.kThongTinKH2.Name = "kThongTinKH2";
            this.kThongTinKH2.Size = new System.Drawing.Size(1080, 860);
            this.kThongTinKH2.TabIndex = 12;
            // 
            // gioiThieuUC1
            // 
            this.gioiThieuUC1.BackColor = System.Drawing.Color.LightBlue;
            this.gioiThieuUC1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("gioiThieuUC1.BackgroundImage")));
            this.gioiThieuUC1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.gioiThieuUC1.Location = new System.Drawing.Point(367, 9);
            this.gioiThieuUC1.Name = "gioiThieuUC1";
            this.gioiThieuUC1.Size = new System.Drawing.Size(1080, 800);
            this.gioiThieuUC1.TabIndex = 13;
            // 
            // KhachHangChinhUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.kThongTinKH2);
            this.Controls.Add(this.panelKhachHang);
            this.Controls.Add(this.gioiThieuUC1);
            this.Name = "KhachHangChinhUC";
            this.Size = new System.Drawing.Size(1443, 879);
            this.Load += new System.EventHandler(this.KhachHangChinhUC_Load);
            this.panelKhachHang.ResumeLayout(false);
            this.panelKhachHang.PerformLayout();
            this.menuStripLogout.ResumeLayout(false);
            this.menuStripLogout.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel panelKhachHang;
        private System.Windows.Forms.Button btnKHoaDon;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnKThueXe;
        private System.Windows.Forms.Button btnKDichVuThue;
        private System.Windows.Forms.Button btnKThongTin;
        private System.Windows.Forms.Panel panelClickKH;
        private System.Windows.Forms.Button btGioiThieuKH;
        private System.Windows.Forms.MenuStrip menuStripLogout;
        private System.Windows.Forms.ToolStripMenuItem menuName;
        private System.Windows.Forms.ToolStripMenuItem menuLogout;
        private KThongTinKH kThongTinKH1;
        private KThongTinKH kThongTinKH2;
        private UserControls.GioiThieuUC gioiThieuUC1;
    }
}
