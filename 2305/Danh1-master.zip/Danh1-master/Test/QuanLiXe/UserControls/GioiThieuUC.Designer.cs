﻿namespace QuanLiXe.UserControls
{
    partial class GioiThieuUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GioiThieuUC));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbxedapDay = new System.Windows.Forms.Label();
            this.lbxedapHour = new System.Windows.Forms.Label();
            this.lbxedapWeek = new System.Windows.Forms.Label();
            this.lbXedapMonth = new System.Windows.Forms.Label();
            this.lbxemayDay = new System.Windows.Forms.Label();
            this.lbxemayHour = new System.Windows.Forms.Label();
            this.lbxemayWeek = new System.Windows.Forms.Label();
            this.lbxemayMonth = new System.Windows.Forms.Label();
            this.lbotoDay = new System.Windows.Forms.Label();
            this.lbotoHour = new System.Windows.Forms.Label();
            this.lbotoWeek = new System.Windows.Forms.Label();
            this.lbotoMonth = new System.Windows.Forms.Label();
            this.pictureBoxOption = new System.Windows.Forms.PictureBox();
            this.pictureBoxRefresh = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOption)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(-117, -345);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1411, 699);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lbxedapDay
            // 
            this.lbxedapDay.AutoSize = true;
            this.lbxedapDay.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxedapDay.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxedapDay.Location = new System.Drawing.Point(72, 682);
            this.lbxedapDay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxedapDay.Name = "lbxedapDay";
            this.lbxedapDay.Size = new System.Drawing.Size(174, 67);
            this.lbxedapDay.TabIndex = 3;
            this.lbxedapDay.Text = "50000";
            // 
            // lbxedapHour
            // 
            this.lbxedapHour.AutoSize = true;
            this.lbxedapHour.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxedapHour.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxedapHour.Location = new System.Drawing.Point(72, 604);
            this.lbxedapHour.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxedapHour.Name = "lbxedapHour";
            this.lbxedapHour.Size = new System.Drawing.Size(174, 67);
            this.lbxedapHour.TabIndex = 4;
            this.lbxedapHour.Text = "50000";
            // 
            // lbxedapWeek
            // 
            this.lbxedapWeek.AutoSize = true;
            this.lbxedapWeek.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxedapWeek.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxedapWeek.Location = new System.Drawing.Point(72, 756);
            this.lbxedapWeek.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxedapWeek.Name = "lbxedapWeek";
            this.lbxedapWeek.Size = new System.Drawing.Size(174, 67);
            this.lbxedapWeek.TabIndex = 5;
            this.lbxedapWeek.Text = "50000";
            // 
            // lbXedapMonth
            // 
            this.lbXedapMonth.AutoSize = true;
            this.lbXedapMonth.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbXedapMonth.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbXedapMonth.Location = new System.Drawing.Point(72, 838);
            this.lbXedapMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbXedapMonth.Name = "lbXedapMonth";
            this.lbXedapMonth.Size = new System.Drawing.Size(174, 67);
            this.lbXedapMonth.TabIndex = 6;
            this.lbXedapMonth.Text = "50000";
            // 
            // lbxemayDay
            // 
            this.lbxemayDay.AutoSize = true;
            this.lbxemayDay.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxemayDay.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxemayDay.Location = new System.Drawing.Point(252, 682);
            this.lbxemayDay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxemayDay.Name = "lbxemayDay";
            this.lbxemayDay.Size = new System.Drawing.Size(174, 67);
            this.lbxemayDay.TabIndex = 7;
            this.lbxemayDay.Text = "50000";
            // 
            // lbxemayHour
            // 
            this.lbxemayHour.AutoSize = true;
            this.lbxemayHour.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxemayHour.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxemayHour.Location = new System.Drawing.Point(252, 604);
            this.lbxemayHour.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxemayHour.Name = "lbxemayHour";
            this.lbxemayHour.Size = new System.Drawing.Size(174, 67);
            this.lbxemayHour.TabIndex = 8;
            this.lbxemayHour.Text = "50000";
            // 
            // lbxemayWeek
            // 
            this.lbxemayWeek.AutoSize = true;
            this.lbxemayWeek.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxemayWeek.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxemayWeek.Location = new System.Drawing.Point(252, 756);
            this.lbxemayWeek.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxemayWeek.Name = "lbxemayWeek";
            this.lbxemayWeek.Size = new System.Drawing.Size(174, 67);
            this.lbxemayWeek.TabIndex = 9;
            this.lbxemayWeek.Text = "50000";
            // 
            // lbxemayMonth
            // 
            this.lbxemayMonth.AutoSize = true;
            this.lbxemayMonth.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxemayMonth.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbxemayMonth.Location = new System.Drawing.Point(252, 838);
            this.lbxemayMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbxemayMonth.Name = "lbxemayMonth";
            this.lbxemayMonth.Size = new System.Drawing.Size(174, 67);
            this.lbxemayMonth.TabIndex = 10;
            this.lbxemayMonth.Text = "50000";
            // 
            // lbotoDay
            // 
            this.lbotoDay.AutoSize = true;
            this.lbotoDay.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbotoDay.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbotoDay.Location = new System.Drawing.Point(436, 682);
            this.lbotoDay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbotoDay.Name = "lbotoDay";
            this.lbotoDay.Size = new System.Drawing.Size(174, 67);
            this.lbotoDay.TabIndex = 11;
            this.lbotoDay.Text = "50000";
            // 
            // lbotoHour
            // 
            this.lbotoHour.AutoSize = true;
            this.lbotoHour.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbotoHour.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbotoHour.Location = new System.Drawing.Point(436, 604);
            this.lbotoHour.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbotoHour.Name = "lbotoHour";
            this.lbotoHour.Size = new System.Drawing.Size(174, 67);
            this.lbotoHour.TabIndex = 12;
            this.lbotoHour.Text = "50000";
            // 
            // lbotoWeek
            // 
            this.lbotoWeek.AutoSize = true;
            this.lbotoWeek.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbotoWeek.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbotoWeek.Location = new System.Drawing.Point(436, 756);
            this.lbotoWeek.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbotoWeek.Name = "lbotoWeek";
            this.lbotoWeek.Size = new System.Drawing.Size(174, 67);
            this.lbotoWeek.TabIndex = 13;
            this.lbotoWeek.Text = "50000";
            // 
            // lbotoMonth
            // 
            this.lbotoMonth.AutoSize = true;
            this.lbotoMonth.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbotoMonth.ForeColor = System.Drawing.Color.DarkGreen;
            this.lbotoMonth.Location = new System.Drawing.Point(436, 838);
            this.lbotoMonth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbotoMonth.Name = "lbotoMonth";
            this.lbotoMonth.Size = new System.Drawing.Size(174, 67);
            this.lbotoMonth.TabIndex = 14;
            this.lbotoMonth.Text = "50000";
            // 
            // pictureBoxOption
            // 
            this.pictureBoxOption.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOption.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxOption.BackgroundImage")));
            this.pictureBoxOption.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxOption.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxOption.Location = new System.Drawing.Point(1383, 16);
            this.pictureBoxOption.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxOption.Name = "pictureBoxOption";
            this.pictureBoxOption.Size = new System.Drawing.Size(41, 68);
            this.pictureBoxOption.TabIndex = 15;
            this.pictureBoxOption.TabStop = false;
            this.pictureBoxOption.Click += new System.EventHandler(this.pictureBoxOption_Click);
            // 
            // pictureBoxRefresh
            // 
            this.pictureBoxRefresh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxRefresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxRefresh.BackgroundImage")));
            this.pictureBoxRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRefresh.Location = new System.Drawing.Point(1301, 16);
            this.pictureBoxRefresh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxRefresh.Name = "pictureBoxRefresh";
            this.pictureBoxRefresh.Size = new System.Drawing.Size(85, 68);
            this.pictureBoxRefresh.TabIndex = 16;
            this.pictureBoxRefresh.TabStop = false;
            this.pictureBoxRefresh.Click += new System.EventHandler(this.pictureBoxRefresh_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(109, 460);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(731, 598);
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // GioiThieuUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightBlue;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBoxRefresh);
            this.Controls.Add(this.pictureBoxOption);
            this.Controls.Add(this.lbotoMonth);
            this.Controls.Add(this.lbotoWeek);
            this.Controls.Add(this.lbotoHour);
            this.Controls.Add(this.lbotoDay);
            this.Controls.Add(this.lbxemayMonth);
            this.Controls.Add(this.lbxemayWeek);
            this.Controls.Add(this.lbxemayHour);
            this.Controls.Add(this.lbxemayDay);
            this.Controls.Add(this.lbXedapMonth);
            this.Controls.Add(this.lbxedapWeek);
            this.Controls.Add(this.lbxedapHour);
            this.Controls.Add(this.lbxedapDay);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "GioiThieuUC";
            this.Size = new System.Drawing.Size(1440, 985);
            this.Load += new System.EventHandler(this.GioiThieuUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOption)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbxedapDay;
        private System.Windows.Forms.Label lbxedapHour;
        private System.Windows.Forms.Label lbxedapWeek;
        private System.Windows.Forms.Label lbXedapMonth;
        private System.Windows.Forms.Label lbxemayDay;
        private System.Windows.Forms.Label lbxemayHour;
        private System.Windows.Forms.Label lbxemayWeek;
        private System.Windows.Forms.Label lbxemayMonth;
        private System.Windows.Forms.Label lbotoDay;
        private System.Windows.Forms.Label lbotoHour;
        private System.Windows.Forms.Label lbotoWeek;
        private System.Windows.Forms.Label lbotoMonth;
        private System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.PictureBox pictureBoxOption;
        public System.Windows.Forms.PictureBox pictureBoxRefresh;
    }
}
