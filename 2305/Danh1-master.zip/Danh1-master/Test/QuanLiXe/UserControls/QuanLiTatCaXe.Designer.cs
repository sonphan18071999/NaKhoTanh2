﻿namespace QuanLiXe.UserControls
{
    partial class QuanLiTatCaXe
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanLiTatCaXe));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.pictureBoxRefresh = new System.Windows.Forms.PictureBox();
            this.labelQuaGioGui = new System.Windows.Forms.Label();
            this.labelDauSaiViTri = new System.Windows.Forms.Label();
            this.dgvQuanLiAllXe = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qUANLIXERAVAOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._DESKTOP_RRRHOP4DataSet = new QuanLiXe._DESKTOP_RRRHOP4DataSet();
            this.pictureBoxXeMay = new System.Windows.Forms.PictureBox();
            this.pictureBoxOto = new System.Windows.Forms.PictureBox();
            this.pictureBoxXeDap = new System.Windows.Forms.PictureBox();
            this.btSua = new System.Windows.Forms.Button();
            this.btSearch = new System.Windows.Forms.Button();
            this.btXoa = new System.Windows.Forms.Button();
            this.qUANLIXERAVAOTableAdapter = new QuanLiXe._DESKTOP_RRRHOP4DataSetTableAdapters.QUANLIXERAVAOTableAdapter();
            this.dgvLuuTruXeDaLay = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn4 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn3 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qLLAYXEBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._DESKTOP_RRRHOP4QLLayXe = new QuanLiXe._DESKTOP_RRRHOP4QLLayXe();
            this.btXeDaLay = new System.Windows.Forms.Button();
            this.btGiaoDienChinh = new System.Windows.Forms.Button();
            this.qLLAYXETableAdapter = new QuanLiXe._DESKTOP_RRRHOP4QLLayXeTableAdapters.QLLAYXETableAdapter();
            this.btSearchLayXe = new System.Windows.Forms.Button();
            this.txtSearchLayXe = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuanLiAllXe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qUANLIXERAVAOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_RRRHOP4DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXeMay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXeDap)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuuTruXeDaLay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLLAYXEBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_RRRHOP4QLLayXe)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.SystemColors.Info;
            this.txtSearch.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.Location = new System.Drawing.Point(191, 27);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(270, 40);
            this.txtSearch.TabIndex = 52;
            // 
            // pictureBoxRefresh
            // 
            this.pictureBoxRefresh.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxRefresh.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxRefresh.BackgroundImage")));
            this.pictureBoxRefresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxRefresh.Location = new System.Drawing.Point(107, 14);
            this.pictureBoxRefresh.Name = "pictureBoxRefresh";
            this.pictureBoxRefresh.Size = new System.Drawing.Size(78, 63);
            this.pictureBoxRefresh.TabIndex = 57;
            this.pictureBoxRefresh.TabStop = false;
            this.pictureBoxRefresh.Click += new System.EventHandler(this.pictureBoxRefresh_Click);
            // 
            // labelQuaGioGui
            // 
            this.labelQuaGioGui.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelQuaGioGui.AutoSize = true;
            this.labelQuaGioGui.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelQuaGioGui.Location = new System.Drawing.Point(663, 27);
            this.labelQuaGioGui.Name = "labelQuaGioGui";
            this.labelQuaGioGui.Size = new System.Drawing.Size(97, 21);
            this.labelQuaGioGui.TabIndex = 58;
            this.labelQuaGioGui.Text = "Quá giờ gửi";
            this.labelQuaGioGui.Visible = false;
            // 
            // labelDauSaiViTri
            // 
            this.labelDauSaiViTri.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelDauSaiViTri.AutoSize = true;
            this.labelDauSaiViTri.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDauSaiViTri.Location = new System.Drawing.Point(654, 48);
            this.labelDauSaiViTri.Name = "labelDauSaiViTri";
            this.labelDauSaiViTri.Size = new System.Drawing.Size(106, 21);
            this.labelDauSaiViTri.TabIndex = 59;
            this.labelDauSaiViTri.Text = "Đậu sai vị trí";
            // 
            // dgvQuanLiAllXe
            // 
            this.dgvQuanLiAllXe.AllowUserToResizeColumns = false;
            this.dgvQuanLiAllXe.AllowUserToResizeRows = false;
            this.dgvQuanLiAllXe.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvQuanLiAllXe.AutoGenerateColumns = false;
            this.dgvQuanLiAllXe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvQuanLiAllXe.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("UVN Anh Hai", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQuanLiAllXe.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvQuanLiAllXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuanLiAllXe.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewImageColumn2,
            this.dataGridViewImageColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn8});
            this.dgvQuanLiAllXe.DataSource = this.qUANLIXERAVAOBindingSource;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQuanLiAllXe.DefaultCellStyle = dataGridViewCellStyle10;
            this.dgvQuanLiAllXe.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvQuanLiAllXe.Location = new System.Drawing.Point(0, 83);
            this.dgvQuanLiAllXe.Name = "dgvQuanLiAllXe";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("UVN Anh Hai", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuanLiAllXe.RowHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvQuanLiAllXe.RowHeadersVisible = false;
            this.dgvQuanLiAllXe.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgvQuanLiAllXe.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvQuanLiAllXe.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvQuanLiAllXe.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvQuanLiAllXe.Size = new System.Drawing.Size(1080, 660);
            this.dgvQuanLiAllXe.TabIndex = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "loaixe";
            this.dataGridViewTextBoxColumn2.HeaderText = "Loại xe";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "vitri";
            this.dataGridViewTextBoxColumn1.HeaderText = "Vị trí";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewImageColumn2.DataPropertyName = "ava";
            this.dataGridViewImageColumn2.HeaderText = "Người gửi xe";
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewImageColumn1.DataPropertyName = "bienso";
            this.dataGridViewImageColumn1.HeaderText = "Biển số xe";
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ngayguixe";
            this.dataGridViewTextBoxColumn3.HeaderText = "Ngày gửi xe";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "gioguixe";
            this.dataGridViewTextBoxColumn4.HeaderText = "Giờ gửi xe";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "timeyeucau";
            this.dataGridViewTextBoxColumn8.HeaderText = "Yêu cầu gửi";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // qUANLIXERAVAOBindingSource
            // 
            this.qUANLIXERAVAOBindingSource.DataMember = "QUANLIXERAVAO";
            this.qUANLIXERAVAOBindingSource.DataSource = this._DESKTOP_RRRHOP4DataSet;
            // 
            // _DESKTOP_RRRHOP4DataSet
            // 
            this._DESKTOP_RRRHOP4DataSet.DataSetName = "_DESKTOP_RRRHOP4DataSet";
            this._DESKTOP_RRRHOP4DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // pictureBoxXeMay
            // 
            this.pictureBoxXeMay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxXeMay.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxXeMay.BackgroundImage")));
            this.pictureBoxXeMay.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxXeMay.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxXeMay.Location = new System.Drawing.Point(779, 0);
            this.pictureBoxXeMay.Name = "pictureBoxXeMay";
            this.pictureBoxXeMay.Size = new System.Drawing.Size(101, 83);
            this.pictureBoxXeMay.TabIndex = 61;
            this.pictureBoxXeMay.TabStop = false;
            this.pictureBoxXeMay.Click += new System.EventHandler(this.pictureBoxXeMay_Click);
            // 
            // pictureBoxOto
            // 
            this.pictureBoxOto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxOto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxOto.BackgroundImage")));
            this.pictureBoxOto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxOto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxOto.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxOto.Image")));
            this.pictureBoxOto.Location = new System.Drawing.Point(878, 0);
            this.pictureBoxOto.Name = "pictureBoxOto";
            this.pictureBoxOto.Size = new System.Drawing.Size(99, 83);
            this.pictureBoxOto.TabIndex = 62;
            this.pictureBoxOto.TabStop = false;
            this.pictureBoxOto.Click += new System.EventHandler(this.pictureBoxOto_Click);
            // 
            // pictureBoxXeDap
            // 
            this.pictureBoxXeDap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxXeDap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxXeDap.BackgroundImage")));
            this.pictureBoxXeDap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBoxXeDap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxXeDap.Location = new System.Drawing.Point(972, 0);
            this.pictureBoxXeDap.Name = "pictureBoxXeDap";
            this.pictureBoxXeDap.Size = new System.Drawing.Size(101, 83);
            this.pictureBoxXeDap.TabIndex = 63;
            this.pictureBoxXeDap.TabStop = false;
            this.pictureBoxXeDap.Click += new System.EventHandler(this.pictureBoxXeDap_Click);
            // 
            // btSua
            // 
            this.btSua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btSua.BackColor = System.Drawing.Color.LightCoral;
            this.btSua.Font = new System.Drawing.Font("UTM Centur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua.Location = new System.Drawing.Point(947, 749);
            this.btSua.Name = "btSua";
            this.btSua.Size = new System.Drawing.Size(126, 46);
            this.btSua.TabIndex = 64;
            this.btSua.Text = "Sửa";
            this.btSua.UseVisualStyleBackColor = false;
            this.btSua.Click += new System.EventHandler(this.btSua_Click_1);
            // 
            // btSearch
            // 
            this.btSearch.BackColor = System.Drawing.Color.Transparent;
            this.btSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btSearch.BackgroundImage")));
            this.btSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btSearch.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSearch.ForeColor = System.Drawing.Color.Transparent;
            this.btSearch.Location = new System.Drawing.Point(436, 27);
            this.btSearch.Name = "btSearch";
            this.btSearch.Size = new System.Drawing.Size(41, 40);
            this.btSearch.TabIndex = 65;
            this.btSearch.UseVisualStyleBackColor = false;
            this.btSearch.Click += new System.EventHandler(this.btSearch_Click);
            // 
            // btXoa
            // 
            this.btXoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btXoa.BackColor = System.Drawing.Color.LightCoral;
            this.btXoa.Font = new System.Drawing.Font("UTM Centur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa.Location = new System.Drawing.Point(928, 749);
            this.btXoa.Name = "btXoa";
            this.btXoa.Size = new System.Drawing.Size(145, 46);
            this.btXoa.TabIndex = 66;
            this.btXoa.Text = "Xóa tất cả";
            this.btXoa.UseVisualStyleBackColor = false;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);
            // 
            // qUANLIXERAVAOTableAdapter
            // 
            this.qUANLIXERAVAOTableAdapter.ClearBeforeFill = true;
            // 
            // dgvLuuTruXeDaLay
            // 
            this.dgvLuuTruXeDaLay.AllowUserToResizeColumns = false;
            this.dgvLuuTruXeDaLay.AllowUserToResizeRows = false;
            this.dgvLuuTruXeDaLay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLuuTruXeDaLay.AutoGenerateColumns = false;
            this.dgvLuuTruXeDaLay.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvLuuTruXeDaLay.BackgroundColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("UVN Anh Hai", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLuuTruXeDaLay.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvLuuTruXeDaLay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLuuTruXeDaLay.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewImageColumn4,
            this.dataGridViewImageColumn3,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.useridDataGridViewTextBoxColumn});
            this.dgvLuuTruXeDaLay.DataSource = this.qLLAYXEBindingSource;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLuuTruXeDaLay.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvLuuTruXeDaLay.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgvLuuTruXeDaLay.Location = new System.Drawing.Point(0, 83);
            this.dgvLuuTruXeDaLay.Name = "dgvLuuTruXeDaLay";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("UVN Anh Hai", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLuuTruXeDaLay.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvLuuTruXeDaLay.RowHeadersVisible = false;
            this.dgvLuuTruXeDaLay.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dgvLuuTruXeDaLay.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvLuuTruXeDaLay.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLuuTruXeDaLay.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvLuuTruXeDaLay.Size = new System.Drawing.Size(1080, 660);
            this.dgvLuuTruXeDaLay.TabIndex = 67;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "loaixe";
            this.dataGridViewTextBoxColumn11.HeaderText = "Loại xe";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 119;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "vitri";
            this.dataGridViewTextBoxColumn10.HeaderText = "Vị trí";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 94;
            // 
            // dataGridViewImageColumn4
            // 
            this.dataGridViewImageColumn4.DataPropertyName = "ava";
            this.dataGridViewImageColumn4.HeaderText = "Người gửi";
            this.dataGridViewImageColumn4.Name = "dataGridViewImageColumn4";
            this.dataGridViewImageColumn4.Width = 123;
            // 
            // dataGridViewImageColumn3
            // 
            this.dataGridViewImageColumn3.DataPropertyName = "bienso";
            this.dataGridViewImageColumn3.HeaderText = "Biển số";
            this.dataGridViewImageColumn3.Name = "dataGridViewImageColumn3";
            this.dataGridViewImageColumn3.Width = 101;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "ngayguixe";
            this.dataGridViewTextBoxColumn12.HeaderText = "Ngày gửi";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 133;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "gioguixe";
            this.dataGridViewTextBoxColumn13.HeaderText = "Giờ gửi";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.Width = 118;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "ngaylayxe";
            this.dataGridViewTextBoxColumn14.HeaderText = "Ngày lấy";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.Width = 132;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "giolayxe";
            this.dataGridViewTextBoxColumn15.HeaderText = "Giờ lấy";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.Width = 117;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "tongTime";
            this.dataGridViewTextBoxColumn16.HeaderText = "Thời gian thực";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.Width = 197;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "timeyeucau";
            this.dataGridViewTextBoxColumn17.HeaderText = "Yêu cầu gửi";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.Width = 163;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "tongtien";
            this.dataGridViewTextBoxColumn18.HeaderText = "Thành tiền";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.Width = 160;
            // 
            // useridDataGridViewTextBoxColumn
            // 
            this.useridDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.useridDataGridViewTextBoxColumn.DataPropertyName = "userid";
            this.useridDataGridViewTextBoxColumn.HeaderText = "User";
            this.useridDataGridViewTextBoxColumn.Name = "useridDataGridViewTextBoxColumn";
            // 
            // qLLAYXEBindingSource
            // 
            this.qLLAYXEBindingSource.DataMember = "QLLAYXE";
            this.qLLAYXEBindingSource.DataSource = this._DESKTOP_RRRHOP4QLLayXe;
            // 
            // _DESKTOP_RRRHOP4QLLayXe
            // 
            this._DESKTOP_RRRHOP4QLLayXe.DataSetName = "_DESKTOP_RRRHOP4QLLayXe";
            this._DESKTOP_RRRHOP4QLLayXe.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btXeDaLay
            // 
            this.btXeDaLay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btXeDaLay.BackColor = System.Drawing.Color.LightCoral;
            this.btXeDaLay.Font = new System.Drawing.Font("UTM Centur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXeDaLay.Location = new System.Drawing.Point(163, 749);
            this.btXeDaLay.Name = "btXeDaLay";
            this.btXeDaLay.Size = new System.Drawing.Size(144, 46);
            this.btXeDaLay.TabIndex = 68;
            this.btXeDaLay.Text = "Xe đã lấy";
            this.btXeDaLay.UseVisualStyleBackColor = false;
            this.btXeDaLay.Click += new System.EventHandler(this.btXeDaLay_Click);
            // 
            // btGiaoDienChinh
            // 
            this.btGiaoDienChinh.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btGiaoDienChinh.BackColor = System.Drawing.Color.LightCoral;
            this.btGiaoDienChinh.Font = new System.Drawing.Font("UTM Centur", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGiaoDienChinh.Location = new System.Drawing.Point(13, 749);
            this.btGiaoDienChinh.Name = "btGiaoDienChinh";
            this.btGiaoDienChinh.Size = new System.Drawing.Size(144, 46);
            this.btGiaoDienChinh.TabIndex = 69;
            this.btGiaoDienChinh.Text = "Quản lí";
            this.btGiaoDienChinh.UseVisualStyleBackColor = false;
            this.btGiaoDienChinh.Click += new System.EventHandler(this.btGiaoDienChinh_Click);
            // 
            // qLLAYXETableAdapter
            // 
            this.qLLAYXETableAdapter.ClearBeforeFill = true;
            // 
            // btSearchLayXe
            // 
            this.btSearchLayXe.BackColor = System.Drawing.Color.Transparent;
            this.btSearchLayXe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btSearchLayXe.BackgroundImage")));
            this.btSearchLayXe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btSearchLayXe.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSearchLayXe.ForeColor = System.Drawing.Color.Transparent;
            this.btSearchLayXe.Location = new System.Drawing.Point(436, 27);
            this.btSearchLayXe.Name = "btSearchLayXe";
            this.btSearchLayXe.Size = new System.Drawing.Size(41, 40);
            this.btSearchLayXe.TabIndex = 71;
            this.btSearchLayXe.UseVisualStyleBackColor = false;
            this.btSearchLayXe.Click += new System.EventHandler(this.btSearchLayXe_Click);
            // 
            // txtSearchLayXe
            // 
            this.txtSearchLayXe.BackColor = System.Drawing.SystemColors.Info;
            this.txtSearchLayXe.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchLayXe.Location = new System.Drawing.Point(191, 27);
            this.txtSearchLayXe.Multiline = true;
            this.txtSearchLayXe.Name = "txtSearchLayXe";
            this.txtSearchLayXe.Size = new System.Drawing.Size(270, 40);
            this.txtSearchLayXe.TabIndex = 70;
            // 
            // QuanLiTatCaXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Controls.Add(this.btSearchLayXe);
            this.Controls.Add(this.txtSearchLayXe);
            this.Controls.Add(this.btSearch);
            this.Controls.Add(this.btGiaoDienChinh);
            this.Controls.Add(this.btXeDaLay);
            this.Controls.Add(this.btSua);
            this.Controls.Add(this.labelDauSaiViTri);
            this.Controls.Add(this.labelQuaGioGui);
            this.Controls.Add(this.pictureBoxRefresh);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.pictureBoxXeDap);
            this.Controls.Add(this.pictureBoxOto);
            this.Controls.Add(this.pictureBoxXeMay);
            this.Controls.Add(this.dgvQuanLiAllXe);
            this.Controls.Add(this.btXoa);
            this.Controls.Add(this.dgvLuuTruXeDaLay);
            this.Name = "QuanLiTatCaXe";
            this.Size = new System.Drawing.Size(1080, 800);
            this.Load += new System.EventHandler(this.QuanLiTatCaXe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuanLiAllXe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qUANLIXERAVAOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_RRRHOP4DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXeMay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxXeDap)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuuTruXeDaLay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLLAYXEBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_RRRHOP4QLLayXe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBoxRefresh;
        private System.Windows.Forms.Label labelQuaGioGui;
        private System.Windows.Forms.Label labelDauSaiViTri;
        private System.Windows.Forms.DataGridView dgvQuanLiAllXe;
        private System.Windows.Forms.PictureBox pictureBoxXeMay;
        private System.Windows.Forms.PictureBox pictureBoxOto;
        private System.Windows.Forms.PictureBox pictureBoxXeDap;
        private System.Windows.Forms.Button btSua;
        private System.Windows.Forms.Button btSearch;
        private System.Windows.Forms.Button btXoa;
        public System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaixeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vitriDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn avaDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewImageColumn biensoDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngayguixeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gioguixeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaylayxeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giolayxeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tongTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn timeyeucauDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tongtienDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource qUANLIXERAVAOBindingSource;
        private _DESKTOP_RRRHOP4DataSet _DESKTOP_RRRHOP4DataSet;
        private _DESKTOP_RRRHOP4DataSetTableAdapters.QUANLIXERAVAOTableAdapter qUANLIXERAVAOTableAdapter;
        private System.Windows.Forms.DataGridView dgvLuuTruXeDaLay;
        private System.Windows.Forms.Button btXeDaLay;
        private System.Windows.Forms.Button btGiaoDienChinh;
        private System.Windows.Forms.BindingSource qLLAYXEBindingSource;
        private _DESKTOP_RRRHOP4QLLayXe _DESKTOP_RRRHOP4QLLayXe;
        private _DESKTOP_RRRHOP4QLLayXeTableAdapters.QLLAYXETableAdapter qLLAYXETableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn4;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn useridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.Button btSearchLayXe;
        public System.Windows.Forms.TextBox txtSearchLayXe;
    }
}
