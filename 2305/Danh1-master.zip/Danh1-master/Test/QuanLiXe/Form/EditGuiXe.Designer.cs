﻿namespace QuanLiXe
{
    partial class EditGuiXe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCancel = new System.Windows.Forms.Button();
            this.btLuu = new System.Windows.Forms.Button();
            this.picBienSo = new System.Windows.Forms.PictureBox();
            this.txtGioGui = new System.Windows.Forms.TextBox();
            this.txtLoaiXe = new System.Windows.Forms.TextBox();
            this.dateTimePickerNgayGui = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picNguoiGui = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.btKhuVuc = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picBienSo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNguoiGui)).BeginInit();
            this.SuspendLayout();
            // 
            // btCancel
            // 
            this.btCancel.BackColor = System.Drawing.Color.Firebrick;
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancel.Font = new System.Drawing.Font("UTM Nyala", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.ForeColor = System.Drawing.Color.White;
            this.btCancel.Location = new System.Drawing.Point(449, 403);
            this.btCancel.Name = "btCancel";
            this.btCancel.Size = new System.Drawing.Size(137, 51);
            this.btCancel.TabIndex = 62;
            this.btCancel.Text = "Đóng";
            this.btCancel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btCancel.UseVisualStyleBackColor = false;
            // 
            // btLuu
            // 
            this.btLuu.BackColor = System.Drawing.Color.Blue;
            this.btLuu.Font = new System.Drawing.Font("UTM Nyala", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLuu.ForeColor = System.Drawing.Color.White;
            this.btLuu.Location = new System.Drawing.Point(322, 403);
            this.btLuu.Name = "btLuu";
            this.btLuu.Size = new System.Drawing.Size(115, 51);
            this.btLuu.TabIndex = 61;
            this.btLuu.Text = "Lưu";
            this.btLuu.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btLuu.UseVisualStyleBackColor = false;
            this.btLuu.Click += new System.EventHandler(this.btLuu_Click);
            // 
            // picBienSo
            // 
            this.picBienSo.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.picBienSo.Location = new System.Drawing.Point(322, 60);
            this.picBienSo.Name = "picBienSo";
            this.picBienSo.Size = new System.Drawing.Size(264, 217);
            this.picBienSo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBienSo.TabIndex = 59;
            this.picBienSo.TabStop = false;
            // 
            // txtGioGui
            // 
            this.txtGioGui.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGioGui.Location = new System.Drawing.Point(144, 416);
            this.txtGioGui.Multiline = true;
            this.txtGioGui.Name = "txtGioGui";
            this.txtGioGui.Size = new System.Drawing.Size(160, 34);
            this.txtGioGui.TabIndex = 54;
            // 
            // txtLoaiXe
            // 
            this.txtLoaiXe.Enabled = false;
            this.txtLoaiXe.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLoaiXe.Location = new System.Drawing.Point(449, 317);
            this.txtLoaiXe.Multiline = true;
            this.txtLoaiXe.Name = "txtLoaiXe";
            this.txtLoaiXe.Size = new System.Drawing.Size(137, 47);
            this.txtLoaiXe.TabIndex = 53;
            // 
            // dateTimePickerNgayGui
            // 
            this.dateTimePickerNgayGui.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePickerNgayGui.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerNgayGui.Location = new System.Drawing.Point(144, 371);
            this.dateTimePickerNgayGui.Name = "dateTimePickerNgayGui";
            this.dateTimePickerNgayGui.Size = new System.Drawing.Size(160, 39);
            this.dateTimePickerNgayGui.TabIndex = 52;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(316, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 34);
            this.label8.TabIndex = 50;
            this.label8.Text = "Biển số";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(443, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 34);
            this.label7.TabIndex = 49;
            this.label7.Text = "Xe";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(34, 411);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 34);
            this.label6.TabIndex = 48;
            this.label6.Text = "Giờ gửi";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(34, 371);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 34);
            this.label5.TabIndex = 47;
            this.label5.Text = "Ngày gửi";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(34, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(113, 34);
            this.label4.TabIndex = 46;
            this.label4.Text = "Người gửi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(34, 280);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 34);
            this.label3.TabIndex = 45;
            this.label3.Text = "Yêu cầu gửi";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(316, 280);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 34);
            this.label1.TabIndex = 43;
            this.label1.Text = "Khu vực";
            // 
            // picNguoiGui
            // 
            this.picNguoiGui.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.picNguoiGui.Location = new System.Drawing.Point(40, 60);
            this.picNguoiGui.Name = "picNguoiGui";
            this.picNguoiGui.Size = new System.Drawing.Size(264, 217);
            this.picNguoiGui.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picNguoiGui.TabIndex = 63;
            this.picNguoiGui.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(40, 317);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(264, 39);
            this.comboBox1.TabIndex = 64;
            // 
            // btKhuVuc
            // 
            this.btKhuVuc.BackColor = System.Drawing.Color.DarkCyan;
            this.btKhuVuc.Font = new System.Drawing.Font("UTM Nyala", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btKhuVuc.ForeColor = System.Drawing.Color.White;
            this.btKhuVuc.Location = new System.Drawing.Point(322, 317);
            this.btKhuVuc.Name = "btKhuVuc";
            this.btKhuVuc.Size = new System.Drawing.Size(115, 47);
            this.btKhuVuc.TabIndex = 65;
            this.btKhuVuc.UseVisualStyleBackColor = false;
            // 
            // EditGuiXe
            // 
            this.AcceptButton = this.btLuu;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DodgerBlue;
            this.CancelButton = this.btCancel;
            this.ClientSize = new System.Drawing.Size(630, 497);
            this.Controls.Add(this.btKhuVuc);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.picNguoiGui);
            this.Controls.Add(this.btCancel);
            this.Controls.Add(this.btLuu);
            this.Controls.Add(this.picBienSo);
            this.Controls.Add(this.txtGioGui);
            this.Controls.Add(this.txtLoaiXe);
            this.Controls.Add(this.dateTimePickerNgayGui);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditGuiXe";
            this.Text = "EditGuiXe";
            this.Load += new System.EventHandler(this.EditGuiXe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBienSo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNguoiGui)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btLuu;
        public System.Windows.Forms.PictureBox picBienSo;
        public System.Windows.Forms.TextBox txtGioGui;
        public System.Windows.Forms.TextBox txtLoaiXe;
        public System.Windows.Forms.DateTimePicker dateTimePickerNgayGui;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox picNguoiGui;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btKhuVuc;
    }
}