﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QuanLiXe
{
    public partial class EditGuiXe : Form
    {
        public EditGuiXe()
        {
            InitializeComponent();
        }

        private void EditGuiXe_Load(object sender, EventArgs e)
        {

        }
        public void loadComboBox()
        {
            
        }

        private void btLuu_Click(object sender, EventArgs e)
        {

        }
    }
}