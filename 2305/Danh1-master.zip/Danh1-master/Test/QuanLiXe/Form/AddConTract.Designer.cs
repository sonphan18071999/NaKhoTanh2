﻿namespace QuanLiXe
{
    partial class AddConTract
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddConTract));
            this.cbTheLoai = new System.Windows.Forms.ComboBox();
            this.radiobtnGui = new System.Windows.Forms.RadioButton();
            this.btnListBox = new System.Windows.Forms.Button();
            this.ListBoxBienSo = new System.Windows.Forms.ListBox();
            this.radiobtnThue = new System.Windows.Forms.RadioButton();
            this.dtpDateStart = new System.Windows.Forms.DateTimePicker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnPaid = new System.Windows.Forms.Button();
            this.btnAddCon = new System.Windows.Forms.Button();
            this.txtBienSo = new System.Windows.Forms.MaskedTextBox();
            this.txtThoiHan = new System.Windows.Forms.MaskedTextBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this._DESKTOP_BAIXE1 = new QuanLiXe._DESKTOP_BAIXE();
            this.txtPaid = new System.Windows.Forms.TextBox();
            this.txtCustomID = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtConID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.eventLog1 = new System.Diagnostics.EventLog();
            this.txtMaKH = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_BAIXE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
            this.SuspendLayout();
            // 
            // cbTheLoai
            // 
            this.cbTheLoai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTheLoai.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTheLoai.FormattingEnabled = true;
            this.cbTheLoai.Location = new System.Drawing.Point(240, 287);
            this.cbTheLoai.Margin = new System.Windows.Forms.Padding(8);
            this.cbTheLoai.Name = "cbTheLoai";
            this.cbTheLoai.Size = new System.Drawing.Size(320, 41);
            this.cbTheLoai.TabIndex = 122;
            // 
            // radiobtnGui
            // 
            this.radiobtnGui.AutoSize = true;
            this.radiobtnGui.BackColor = System.Drawing.Color.SteelBlue;
            this.radiobtnGui.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnGui.ForeColor = System.Drawing.Color.White;
            this.radiobtnGui.Location = new System.Drawing.Point(401, 201);
            this.radiobtnGui.Margin = new System.Windows.Forms.Padding(8);
            this.radiobtnGui.Name = "radiobtnGui";
            this.radiobtnGui.Size = new System.Drawing.Size(131, 37);
            this.radiobtnGui.TabIndex = 100;
            this.radiobtnGui.TabStop = true;
            this.radiobtnGui.Text = "Cho Gửi";
            this.radiobtnGui.UseVisualStyleBackColor = false;
            this.radiobtnGui.CheckedChanged += new System.EventHandler(this.radiobtnGui_CheckedChanged);
            // 
            // btnListBox
            // 
            this.btnListBox.BackColor = System.Drawing.Color.RosyBrown;
            this.btnListBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnListBox.BackgroundImage")));
            this.btnListBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnListBox.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnListBox.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListBox.Location = new System.Drawing.Point(480, 373);
            this.btnListBox.Margin = new System.Windows.Forms.Padding(8);
            this.btnListBox.Name = "btnListBox";
            this.btnListBox.Size = new System.Drawing.Size(80, 41);
            this.btnListBox.TabIndex = 121;
            this.btnListBox.UseVisualStyleBackColor = false;
            this.btnListBox.Click += new System.EventHandler(this.btnListBox_Click);
            // 
            // ListBoxBienSo
            // 
            this.ListBoxBienSo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ListBoxBienSo.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListBoxBienSo.FormattingEnabled = true;
            this.ListBoxBienSo.ItemHeight = 33;
            this.ListBoxBienSo.Location = new System.Drawing.Point(592, 114);
            this.ListBoxBienSo.Margin = new System.Windows.Forms.Padding(8);
            this.ListBoxBienSo.Name = "ListBoxBienSo";
            this.ListBoxBienSo.Size = new System.Drawing.Size(432, 499);
            this.ListBoxBienSo.TabIndex = 120;
            // 
            // radiobtnThue
            // 
            this.radiobtnThue.AutoSize = true;
            this.radiobtnThue.BackColor = System.Drawing.Color.SteelBlue;
            this.radiobtnThue.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnThue.ForeColor = System.Drawing.Color.White;
            this.radiobtnThue.Location = new System.Drawing.Point(240, 199);
            this.radiobtnThue.Margin = new System.Windows.Forms.Padding(8);
            this.radiobtnThue.Name = "radiobtnThue";
            this.radiobtnThue.Size = new System.Drawing.Size(145, 37);
            this.radiobtnThue.TabIndex = 99;
            this.radiobtnThue.TabStop = true;
            this.radiobtnThue.Text = "Cho Thuê";
            this.radiobtnThue.UseVisualStyleBackColor = false;
            // 
            // dtpDateStart
            // 
            this.dtpDateStart.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateStart.Location = new System.Drawing.Point(240, 462);
            this.dtpDateStart.Margin = new System.Windows.Forms.Padding(8);
            this.dtpDateStart.Name = "dtpDateStart";
            this.dtpDateStart.Size = new System.Drawing.Size(320, 41);
            this.dtpDateStart.TabIndex = 119;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.SteelBlue;
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnCancel.Font = new System.Drawing.Font("UTM Azuki", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnCancel.Location = new System.Drawing.Point(882, 619);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(8);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(142, 74);
            this.btnCancel.TabIndex = 118;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnPaid
            // 
            this.btnPaid.BackColor = System.Drawing.Color.Teal;
            this.btnPaid.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPaid.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaid.ForeColor = System.Drawing.Color.White;
            this.btnPaid.Location = new System.Drawing.Point(851, 35);
            this.btnPaid.Margin = new System.Windows.Forms.Padding(8);
            this.btnPaid.Name = "btnPaid";
            this.btnPaid.Size = new System.Drawing.Size(173, 71);
            this.btnPaid.TabIndex = 117;
            this.btnPaid.Text = "Thanh Toán";
            this.btnPaid.UseVisualStyleBackColor = false;
            this.btnPaid.Click += new System.EventHandler(this.btnPaid_Click);
            // 
            // btnAddCon
            // 
            this.btnAddCon.BackColor = System.Drawing.Color.SteelBlue;
            this.btnAddCon.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddCon.BackgroundImage")));
            this.btnAddCon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnAddCon.Font = new System.Drawing.Font("UTM Azuki", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCon.ForeColor = System.Drawing.Color.SaddleBrown;
            this.btnAddCon.Location = new System.Drawing.Point(722, 619);
            this.btnAddCon.Margin = new System.Windows.Forms.Padding(8);
            this.btnAddCon.Name = "btnAddCon";
            this.btnAddCon.Size = new System.Drawing.Size(155, 74);
            this.btnAddCon.TabIndex = 116;
            this.btnAddCon.Text = "Add";
            this.btnAddCon.UseVisualStyleBackColor = false;
            this.btnAddCon.Click += new System.EventHandler(this.btnAddCon_Click);
            // 
            // txtBienSo
            // 
            this.txtBienSo.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBienSo.Location = new System.Drawing.Point(240, 373);
            this.txtBienSo.Margin = new System.Windows.Forms.Padding(5);
            this.txtBienSo.Name = "txtBienSo";
            this.txtBienSo.Size = new System.Drawing.Size(227, 41);
            this.txtBienSo.TabIndex = 114;
            // 
            // txtThoiHan
            // 
            this.txtThoiHan.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtThoiHan.Location = new System.Drawing.Point(240, 114);
            this.txtThoiHan.Margin = new System.Windows.Forms.Padding(5);
            this.txtThoiHan.Name = "txtThoiHan";
            this.txtThoiHan.Size = new System.Drawing.Size(320, 41);
            this.txtThoiHan.TabIndex = 115;
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(240, 652);
            this.txtDescription.Margin = new System.Windows.Forms.Padding(5);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(320, 41);
            this.txtDescription.TabIndex = 112;
            // 
            // _DESKTOP_BAIXE1
            // 
            this._DESKTOP_BAIXE1.DataSetName = "_DESKTOP_BAIXE";
            this._DESKTOP_BAIXE1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtPaid
            // 
            this.txtPaid.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPaid.Location = new System.Drawing.Point(240, 557);
            this.txtPaid.Margin = new System.Windows.Forms.Padding(5);
            this.txtPaid.Name = "txtPaid";
            this.txtPaid.Size = new System.Drawing.Size(320, 41);
            this.txtPaid.TabIndex = 113;
            // 
            // txtCustomID
            // 
            this.txtCustomID.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomID.Location = new System.Drawing.Point(2181, 41);
            this.txtCustomID.Margin = new System.Windows.Forms.Padding(5);
            this.txtCustomID.Name = "txtCustomID";
            this.txtCustomID.ReadOnly = true;
            this.txtCustomID.Size = new System.Drawing.Size(380, 29);
            this.txtCustomID.TabIndex = 111;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.SteelBlue;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(42, 203);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 33);
            this.label7.TabIndex = 106;
            this.label7.Text = "Phương Thức";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SteelBlue;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(44, 295);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 33);
            this.label3.TabIndex = 105;
            this.label3.Text = "Loại xe";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.BackColor = System.Drawing.Color.SteelBlue;
            this.Address.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address.ForeColor = System.Drawing.Color.White;
            this.Address.Location = new System.Drawing.Point(44, 652);
            this.Address.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(104, 33);
            this.Address.TabIndex = 104;
            this.Address.Text = "Ghi chú";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.SteelBlue;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(44, 381);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 33);
            this.label4.TabIndex = 102;
            this.label4.Text = "Biển Số";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.SteelBlue;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(42, 468);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 33);
            this.label6.TabIndex = 107;
            this.label6.Text = "Ngày bắt đầu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.SteelBlue;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(42, 122);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 33);
            this.label8.TabIndex = 108;
            this.label8.Text = "Thời hạn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(586, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 33);
            this.label2.TabIndex = 109;
            this.label2.Text = "Mã KH";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SteelBlue;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(42, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 33);
            this.label1.TabIndex = 101;
            this.label1.Text = "Mã Hợp Đồng";
            // 
            // txtConID
            // 
            this.txtConID.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConID.Location = new System.Drawing.Point(240, 35);
            this.txtConID.Margin = new System.Windows.Forms.Padding(5);
            this.txtConID.Name = "txtConID";
            this.txtConID.Size = new System.Drawing.Size(190, 41);
            this.txtConID.TabIndex = 110;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.SteelBlue;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(42, 560);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 33);
            this.label5.TabIndex = 103;
            this.label5.Text = "Thanh Toán";
            // 
            // eventLog1
            // 
            this.eventLog1.SynchronizingObject = this;
            // 
            // txtMaKH
            // 
            this.txtMaKH.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKH.Location = new System.Drawing.Point(696, 35);
            this.txtMaKH.Margin = new System.Windows.Forms.Padding(5);
            this.txtMaKH.Name = "txtMaKH";
            this.txtMaKH.ReadOnly = true;
            this.txtMaKH.Size = new System.Drawing.Size(137, 41);
            this.txtMaKH.TabIndex = 123;
            // 
            // AddConTract
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1082, 739);
            this.Controls.Add(this.txtMaKH);
            this.Controls.Add(this.cbTheLoai);
            this.Controls.Add(this.radiobtnGui);
            this.Controls.Add(this.btnListBox);
            this.Controls.Add(this.ListBoxBienSo);
            this.Controls.Add(this.radiobtnThue);
            this.Controls.Add(this.dtpDateStart);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnPaid);
            this.Controls.Add(this.btnAddCon);
            this.Controls.Add(this.txtBienSo);
            this.Controls.Add(this.txtThoiHan);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.txtPaid);
            this.Controls.Add(this.txtCustomID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtConID);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "AddConTract";
            this.Text = "AddConTract";
            this.Load += new System.EventHandler(this.AddConTract_Load);
            ((System.ComponentModel.ISupportInitialize)(this._DESKTOP_BAIXE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbTheLoai;
        private System.Windows.Forms.RadioButton radiobtnGui;
        private System.Windows.Forms.Button btnListBox;
        private System.Windows.Forms.ListBox ListBoxBienSo;
        private System.Windows.Forms.RadioButton radiobtnThue;
        public System.Windows.Forms.DateTimePicker dtpDateStart;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnPaid;
        private System.Windows.Forms.Button btnAddCon;
        public System.Windows.Forms.MaskedTextBox txtBienSo;
        public System.Windows.Forms.MaskedTextBox txtThoiHan;
        private System.Windows.Forms.TextBox txtDescription;
        private _DESKTOP_BAIXE _DESKTOP_BAIXE1;
        private System.Windows.Forms.TextBox txtPaid;
        public System.Windows.Forms.TextBox txtCustomID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtConID;
        private System.Windows.Forms.Label label5;
        private System.Diagnostics.EventLog eventLog1;
        private System.Windows.Forms.TextBox txtMaKH;
    }
}